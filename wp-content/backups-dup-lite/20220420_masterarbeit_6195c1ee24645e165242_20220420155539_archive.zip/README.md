# de_akademily_landing

```
admin  
NQ3rZbj3QBtWgF%%Il
```
Домены и названия сайтов
```
gwrites-ma.de - для Masterarbeit
gwrites-da.de - для Doktorarbeit
gwrites-statistik.de - для Statistik
gwrites-fa.de - для Facharbeit
gwrites-abschluss.de - для Abschlussarbeit
gwrites-artikel.de - для Forschungsartikel
```